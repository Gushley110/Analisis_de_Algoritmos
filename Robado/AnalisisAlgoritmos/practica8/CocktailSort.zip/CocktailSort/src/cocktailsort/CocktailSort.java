//Escuela Superior de Computo Instituto Politecnico Nacional
//Padilla Calderon Jose Manuel	
//Salgado Alarcon Genaro
//Analisis de Algoritmos - Dr. Luna Benoso Benjamin 3CV2
//Practica 8 Algoritmos de Ordenacion

package cocktailsort;
import java.util.*;

public class CocktailSort {
    public static int pasos;
    
    
    void cocktailSort(int[] arreglo){
        int inicio=0; 
        int fin = arreglo.length;
        int aux;
        boolean bandera = true;
        
        while(bandera == true){
            pasos = pasos+1;
            bandera = false;
            
            //Burbuja hacia la derecha
            for(int i=inicio; i<(fin-1); i++){
                pasos = pasos+1;
                
                if( arreglo[i] > arreglo[i+1] ){
                    pasos = pasos+1;
                    aux = arreglo[i];
                    arreglo[i] = arreglo[i+1];
                    arreglo[i+1] = aux;
                    bandera = true;
                }
            }
            
            //Si no se movió nada, ya está ordenado
            if(bandera == false){
                pasos = pasos+1;
                break;
            }
            
            bandera = false;
            fin = fin-1;
            
            //Burbuja hacia la izquierda
            for(int i=fin-1; i>=inicio; i--){
                pasos = pasos+1;
                
                if( arreglo[i] > arreglo[i+1] ){
                    pasos = pasos+1;
                    aux = arreglo[i];
                    arreglo[i] = arreglo[i+1];
                    arreglo[i+1] = aux;
                    bandera = true;
                }
            }
            
            inicio = inicio+1;
            
        } //Fin WHILE
    }
    
    void imprimirArreglo(int[] arreglo){
        for(int i=0; i<arreglo.length; i++){
            System.out.print(+arreglo[i]+ ", ");
        }
        System.out.println(" ");
    }
    
    public static void main(String[] args) {
        CocktailSort cocktail = new CocktailSort();
        Scanner entrada =  new Scanner(System.in);
        int tamanio, aux;
        int[] arreglo;
        
        for(int i=1; i<=50; i++){
            pasos = 0;
            arreglo = new int[i];
            tamanio = arreglo.length;
            
            for(int j=0; j<tamanio; j++){
                arreglo[j] = (int)( Math.random()*100 );
            }
            
            cocktail.cocktailSort(arreglo);
            System.out.println("Tamaño del arreglo: " +i);
            System.out.println("Numero de pasos: " +pasos);
            System.out.println(" ");
        }
        
    }
    
}
