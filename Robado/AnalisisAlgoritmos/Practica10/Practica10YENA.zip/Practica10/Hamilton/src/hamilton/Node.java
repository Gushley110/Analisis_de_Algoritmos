//Escuela Superior de Computo Instituto Politecnico Nacional
//Padilla Calderon Jose Manuel	
//Salgado Alarcon Genaro
//Analisis de Algoritmos - Dr. Luna Benoso Benjamin 3CV2
//Practica 10 Verificacion en Tiempo Polinomial

import java.util.*;

public class Node{
	int n;
	ArrayList<Node> ad;

	public Node(int n){
		this.n=n;
		//this.ad=ad;
	}
}