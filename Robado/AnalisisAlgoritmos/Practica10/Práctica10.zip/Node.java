import java.util.*;

public class Node{
	int n;
	ArrayList<Node> ad;

	public Node(int n){
		this.n=n;
		//this.ad=ad;
	}
}